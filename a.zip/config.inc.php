<?php
if (!defined('ACCESS')) die('Not access');
else $configs = array(
    'username' => 'admin',
    'password' => '1f32aa4c9a1d2ea010adcf2348166a04',
    'page_list' => '0',
    'page_file_edit' => '0',
    'page_file_edit_line' => '0',
    'page_database_list_rows' => '0'
);
